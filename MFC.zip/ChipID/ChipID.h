// ChipID.h : main header file for the CHIPID application
//

#if !defined(AFX_CHIPID_H__260E9C1D_2846_4826_88B7_61DDE38A5F76__INCLUDED_)
#define AFX_CHIPID_H__260E9C1D_2846_4826_88B7_61DDE38A5F76__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CChipIDApp:
// See ChipID.cpp for the implementation of this class
//

class CChipIDApp : public CWinApp
{
public:
	CChipIDApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CChipIDApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CChipIDApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CHIPID_H__260E9C1D_2846_4826_88B7_61DDE38A5F76__INCLUDED_)
